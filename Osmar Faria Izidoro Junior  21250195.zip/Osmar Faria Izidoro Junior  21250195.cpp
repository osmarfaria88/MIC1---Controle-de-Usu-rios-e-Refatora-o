/*
 * mic1_vm_personal.c
 *
 * Implementa��o simples de uma VM de pilha (instru��es tipo MIC1/JVM).
 * Eu (seu-nome-aqui) implementei esta vers�o para testar pequenas rotinas
 * aritm�ticas, controle de fluxo e opera��es de mem�ria local.
 *
 * Observa��es:
 * - Mantive a interface simples: ./mic1_vm_personal prog.bin
 * - Arquivo prog.bin cont�m os bytes das instru��es.
 *
 * Se voc� recebeu ajuda externa ao escrever este c�digo, declare-a
 * conforme requerido pela sua institui��o/projeto.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define MEMSIZE   (1<<20)   // 1 MB de "mem�ria" para programa/dados
#define STACKSIZE (1<<16)   // Espa�o da pilha

/* C�digos das instru��es que uso nesta VM */
enum {
    OP_BIPUSH = 0x10,
    OP_SIPUSH = 0x11,
    OP_POP    = 0x57,
    OP_DUP    = 0x59,
    OP_SWAP   = 0x5f,
    OP_IADD   = 0x60,
    OP_ISUB   = 0x64,
    OP_IMUL   = 0x68,
    OP_IDIV   = 0x6c,
    OP_ILOAD  = 0x15,
    OP_ISTORE = 0x36,
    OP_GOTO   = 0xa7,
    OP_IFEQ   = 0x99,
    OP_IFLT   = 0x9b,
    OP_PRINT  = 0xFE, // instru��o personalizada para depura��o/sa�da
    OP_HALT   = 0xFF  // encerra a execu��o
};

/* Estado da VM */
static int32_t stack_mem[STACKSIZE];
static int sp = 0;                // ponteiro para o topo (pr�xima posi��o livre)
static int32_t locals[256];       // espa�os de vari�veis locais (�ndices 0..255)
static uint8_t mem[MEMSIZE];
static size_t memlen = 0;
static uint32_t pc = 0;

/* Empilha valor (com checagem simples) */
void push(int32_t v) {
    if (sp >= STACKSIZE) {
        fprintf(stderr, "ERRO: overflow de pilha\n");
        exit(1);
    }
    stack_mem[sp++] = v;
}

/* Desempilha valor (com checagem simples) */
int32_t pop_val(void) {
    if (sp <= 0) {
        fprintf(stderr, "ERRO: underflow de pilha\n");
        exit(1);
    }
    return stack_mem[--sp];
}

/* L� um signed 16-bit big-endian da mem�ria (como JVM) */
int16_t read_s16(uint32_t addr) {
    uint8_t b1 = mem[addr];
    uint8_t b2 = mem[addr + 1];
    return (int16_t)((b1 << 8) | b2);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Uso: %s prog.bin\n", argv[0]);
        return 1;
    }

    /* Carrego o bin�rio do programa na mem�ria */
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("Erro abrindo arquivo"); return 1; }
    memlen = fread(mem, 1, MEMSIZE, f);
    fclose(f);
    if (memlen == 0) { fprintf(stderr, "Arquivo vazio ou n�o lido\n"); return 1; }

    /* Inicializo estado */
    pc = 0;
    sp = 0;
    for (int i = 0; i < 256; ++i) locals[i] = 0;

    /* Ciclo principal de fetch-decode-execute */
    while (pc < memlen) {
        uint8_t op = mem[pc++];

        switch (op) {
            case OP_BIPUSH: {
                int8_t val = (int8_t)mem[pc++];
                push((int32_t)val);
                break;
            }
            case OP_SIPUSH: {
                int16_t sval = read_s16(pc);
                pc += 2;
                push((int32_t)sval);
                break;
            }
            case OP_POP:
                (void)pop_val();
                break;
            case OP_DUP:
                if (sp <= 0) { fprintf(stderr, "dup em pilha vazia\n"); exit(1); }
                push(stack_mem[sp - 1]);
                break;
            case OP_SWAP:
                if (sp < 2) { fprintf(stderr, "swap precisa de 2 itens\n"); exit(1); }
                {
                    int32_t a = pop_val();
                    int32_t b = pop_val();
                    push(a);
                    push(b);
                }
                break;
            case OP_IADD:
                {
                    int32_t a = pop_val();
                    int32_t b = pop_val();
                    push(b + a);
                }
                break;
            case OP_ISUB:
                {
                    int32_t a = pop_val();
                    int32_t b = pop_val();
                    push(b - a);
                }
                break;
            case OP_IMUL:
                {
                    int32_t a = pop_val();
                    int32_t b = pop_val();
                    push(b * a);
                }
                break;
            case OP_IDIV:
                {
                    int32_t a = pop_val();
                    int32_t b = pop_val();
                    if (a == 0) { fprintf(stderr, "Erro: divis�o por zero\n"); exit(1); }
                    push(b / a);
                }
                break;
            case OP_ILOAD:
                {
                    uint8_t idx = mem[pc++];
                    push(locals[idx]);
                }
                break;
            case OP_ISTORE:
                {
                    uint8_t idx = mem[pc++];
                    locals[idx] = pop_val();
                }
                break;
            case OP_GOTO:
                {
                    int16_t offset = read_s16(pc);
                    pc = (uint32_t)((int32_t)pc + 2 + offset);
                }
                break;
            case OP_IFEQ:
            case OP_IFLT:
                {
                    int16_t offset = read_s16(pc);
                    pc += 2;
                    int32_t v = pop_val();
                    int take = 0;
                    if (op == OP_IFEQ && v == 0) take = 1;
                    if (op == OP_IFLT && v < 0) take = 1;
                    if (take) pc = (uint32_t)((int32_t)pc + offset);
                }
                break;
            case OP_PRINT:
                printf("%d\n", pop_val());
                fflush(stdout);
                break;
            case OP_HALT:
                /* Terminei a execu��o � retorno com sucesso */
                return 0;
            default:
                fprintf(stderr, "Instru��o desconhecida 0x%02x em pc=%u\n", op, pc - 1);
                return 1;
        }
    }

    return 0;
}

